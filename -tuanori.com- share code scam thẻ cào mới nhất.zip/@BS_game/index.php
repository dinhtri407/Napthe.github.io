<!--
/* Source : Scam Card Game Auto 2.0
- Author : Duong Viet Thang (BiSexy)
- Contact : FB.Com/8612.DVT
- Code by : Duong Viet Thang (BiSexy)
- Theme by : Vo Huu Nhan (Blackspy)
*/
-->