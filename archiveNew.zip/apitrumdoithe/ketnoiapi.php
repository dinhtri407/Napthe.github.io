<?php
$trumdoitheApiKey = "uczq4iFgWMP0VfkRjd1tvoLIeb8Up9hQ"; //API BÊN NHANTHECAO.COM
$callback_url = " tên miền /callback.php"; // THAY TÊN WEBSITE
// LIÊN HỆ TUẤN ORI NẾU KHÔNG BIẾT LÀM